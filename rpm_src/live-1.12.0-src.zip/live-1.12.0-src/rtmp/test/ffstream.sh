ffmpeg -loglevel verbose -re -i ~/movie.avi  -f flv rtmp://localhost/myapp/mystream
